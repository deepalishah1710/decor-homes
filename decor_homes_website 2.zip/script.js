document.addEventListener("DOMContentLoaded", function() {
    alert("Welcome to Decor Homes - Luxury Interior Design!");
});